﻿using FindKeyChallenge.Model;
using Microsoft.AspNetCore.Mvc;

namespace FindKeyChallenge.Controllers
{

    [ApiController]
    [Route("API/[controller]")]
    public class FiapChallengeController : ControllerBase
    {
        public FiapChallengeController()
        {
                
        }

        [HttpPost]
        public IActionResult FindKey(RequestData request)
        {

            //string Key = "A3232C";
            string Key = "A0A";
            if (Key.Equals(request.Key))
                return Ok();

            return NoContent();

        }
    }
}

