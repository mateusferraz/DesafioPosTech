﻿namespace FindKeyChallenge.Model
{
    public class RequestData
    {
        public string Key { get; set; }
    }
}
